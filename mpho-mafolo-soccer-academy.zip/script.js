const menuToggle = document.getElementById('menuToggle');
const mainNav = document.getElementById('mainNav');
menuToggle.addEventListener('click', () => {
  const open = mainNav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
  menuToggle.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
});
mainNav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  mainNav.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
}));
document.getElementById('year').textContent = new Date().getFullYear();

const form = document.getElementById('registrationForm');
const status = document.getElementById('formStatus');
const dob = form.elements.dateOfBirth;
const today = new Date().toISOString().slice(0, 10);
dob.max = today;

form.addEventListener('submit', event => {
  event.preventDefault();
  if (!form.reportValidity()) return;
  // This starter website has no registration server connected yet.
  // Do not collect or transmit children's information until a secure destination
  // and an appropriate privacy notice have been configured by the academy.
  status.textContent = 'The form is ready, but online submissions are not active yet. Your details have NOT been sent or saved. Please contact the academy directly until a secure registration service is connected.';
  status.scrollIntoView({ behavior: 'smooth', block: 'center' });
});
