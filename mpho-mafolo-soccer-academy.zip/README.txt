MPHO MAFОLO SOCCER ACADEMY WEBSITE

FILES
- index.html: website content
- style.css: design and mobile layout
- script.js: navigation and registration form validation

PREVIEW
Open index.html in a browser. Internet is needed for the Google Fonts and background photos.

IMPORTANT REGISTRATION NOTE
The registration form is currently a front-end demonstration. It validates required fields but does NOT send or store submissions. Before collecting information about children, connect a secure form backend and publish a clear privacy notice explaining who receives the data, why it is needed, how long it is kept, and how a parent/guardian can request its deletion. Do not publish the form as an active registration channel until this is done.

PUBLISH WITH GITHUB PAGES
1. Create a GitHub repository.
2. Upload index.html, style.css, script.js and README.txt to the repository's main/root folder.
3. Open repository Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Choose main and /(root), then Save.
6. Wait for the Pages URL to appear.
